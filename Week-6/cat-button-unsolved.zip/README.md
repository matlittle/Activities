# Cat Button

## File

* [`cat-button`](Unsolved/cat-button.html)

## Instructions

* Open the file `01-cat-button-students.html` in your browser. Then take a few moments to see what the application does.

* Then fill in the missing comments for each line to describe what each section does.
